﻿namespace Nikse.SubtitleEdit.PluginLogic
{
    internal static class Configuration
    {
        public static double CurrentFrameRate = 23.976;
        public static string ListViewLineSeparatorString = "<br />";
    }
}
